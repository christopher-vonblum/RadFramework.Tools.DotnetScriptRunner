1. Download download/cs-script-[VERSION].zip
2. Unzip it
3. Move to the folder where library and data should reside
4. Execute INSTALL.sh
5. Manually execute TestScript.csx from the terminal again
6. If you get a message that the installation was successful you are ready ;)

Your files need the header:
#!/usr/bin/cs-script

on top of the file.

After that adittionally chmod +x them.

Plain C# follows right after the header.

Execute a script from the terminal by typing
./script.cs
or 
./script.csx

Have fun :)
