#!/bin/sh -v
sudo rm /usr/bin/cs-script
sudo rm /usr/bin/cs-script.cfg