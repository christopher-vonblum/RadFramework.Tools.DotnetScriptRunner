#!/usr/bin/cs-script
Console.WriteLine("Successfully installed");
Console.WriteLine("This message comes from an c# script.");